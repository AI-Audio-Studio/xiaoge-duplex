# Xiaoge C Client SDK R5.2.2

This SDK implements the R5.2.2 WSS session path with libwebsockets:

```text
create_session request JSON -> caller HTTP layer
session.created -> WSS /ws/session + Authorization: Bearer -> ctrl.hello
-> PCM + ctrl/data JSON -> fake cmd_ack/cmd_result
```

The SDK does not connect to real robot actions by default. `data.cmd` is
acknowledged and completed through the built-in fake executor behavior. Set
`cfg.auto_fake_cmd_executor = XIAOGE_AUTO_FAKE_CMD_DISABLED` when an embedding
application wants to execute commands itself and report real status.

## Build from this package

Run from the `xiaoge-c-sdk-r5.2.2` package root:

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Install `libwebsockets` with TLS support, `libcurl`, and `cmake` first. On
Linux, `libwebsockets-dev`, `libcurl4-openssl-dev`, and `cmake` are sufficient
on most distributions.

For Android cross builds, `ctest` does not execute the Android ELF on the host.
The `xiaoge_c_codec_test` target is registered through the package adb wrapper
at `cmake/run_adb_test.cmake`. At configure time CMake finds `adb` from
`ANDROID_HOME`, `ANDROID_SDK_ROOT`, or `PATH`, then `ctest` pushes the test
binary to `/data/local/tmp`, marks it executable, and runs it on the connected
device.

## API

```c
xiaoge_config cfg = {
    "robot-x3-001",
    "{"key_id":"dev","signature":"mock"}",
    "audio,text,cmd,state",
    "xiaoge-c-sdk-r5.2.2",
    "{}",
    XIAOGE_CLOUD_API_KEY environment variable,
    XIAOGE_AUTO_FAKE_CMD_DEFAULT
};
char body[2048];
xiaoge_build_create_session_request(&cfg, body, sizeof(body));
```

By default the SDK fake executor sends `data.cmd_ack` plus `data.cmd_result`
`running/succeeded` for downlink `data.cmd`. For a real executor, disable that
behavior and send command status explicitly from `on_cmd` or your worker thread:

```c
static xiaoge_client *g_client;

static void on_cmd(const char *cmd_json, void *user) {
    (void)user;
    xiaoge_send_cmd_ack(g_client, cmd_json, "accepted", "ok", "queued");
    xiaoge_send_cmd_result(g_client, cmd_json, "running", "ok", "started", 0);
    xiaoge_send_cmd_result(g_client, cmd_json, "succeeded", "ok", "completed", 0);
}

xiaoge_config cfg = {
    "robot-x3-001",
    "{"key_id":"dev","signature":"mock"}",
    "audio,text,cmd,state",
    "xiaoge-c-sdk-r5.2.2",
    "{}",
    NULL,
    XIAOGE_AUTO_FAKE_CMD_DISABLED
};
```

`xiaoge_send_cmd_ack` accepts `accepted`, `rejected`, or `duplicate`.
`xiaoge_send_cmd_result` accepts `running`, `succeeded`, `failed`, `canceled`, or
`timeout`. Both functions derive `trace_id`, `session_id`, `utterance_id`, and
`cmd_id` from the original downlink `data.cmd` JSON.

Submit `body` to the cloud fake server or test Gateway create_session endpoint.
Then pass the returned `session.created` fields to the SDK:

```c
xiaoge_session s = {
    trace_id,
    session_id,
    access_token,
    ws_url,              /* must be ws(s)://host[:port]/ws/session */
    "audio,text,cmd,state",
    config_version
};
xiaoge_client *c = xiaoge_create_from_session_with_ca(
    &cfg,
    &s,
    "certs/cloud-ca.pem",
    0,
    &callbacks
);
xiaoge_send_frontend_state(c, "hint", "awake", "speech", 1000);
xiaoge_send_pcm(c, pcm, len);
while (xiaoge_service(c, 20) == 0) {}
xiaoge_destroy(c);
```

## File demo

After building from the package root:

```bash
./build/xiaoge_demo_file <create_session_url> <device_id> <credential-json-or-string> in.wav out.wav [--ca-cert certs/cloud-ca.pem]
```

The demo performs `create_session` internally through libcurl, then connects to
the returned `ws_url`.

Compatibility mode is still available when your test harness has already called
`create_session`:

```bash
./build/xiaoge_demo_file <ws_url> <access_token> <trace_id> <session_id> <device_id> in.wav out.wav [--ca-cert certs/cloud-ca.pem]
```

`in.wav` must be 16000 Hz, mono, signed 16-bit PCM.

`--insecure` remains available for isolated test environments only. The C SDK
sends only `Authorization: Bearer <access_token>` on WSS upgrade requests; the
embedding HTTP layer must also send the same header when it performs
`create_session`.

## Local proxy

If a local firewall blocks the C demo process from connecting directly to the
remote gateway, run the local Python proxy and point the demo at `127.0.0.1`.
The demo connects to the proxy over local cleartext HTTP/WS; the proxy connects
upstream over HTTPS/WSS and rewrites the `create_session` response `ws_url` to
`ws://127.0.0.1:10097/ws/session`.

The proxy uses `aiohttp`. If your environment does not already have it, install
it into the environment you use to run SDK tools:

```bash
python -m pip install aiohttp
```

Start the proxy from the package root:

```bash
python examples/local_proxy.py
```

Then run the demo against the local `create_session` URL:

```bash
./build/xiaoge_demo_file http://127.0.0.1:10097/create_session   robot-x3-001 '{"key_id":"dev","signature":"mock"}' in.wav out.wav --insecure
```

Keep the proxy running while the demo is active. The local URL must use
`http://`; the websocket URL returned to the demo will use local `ws://`. The
proxy handles upstream `https://` and `wss://`.

Optional settings can be placed next to the script in
`examples/local_proxy_config.json`:

```json
{
  "server_host": "60.205.197.165",
  "server_port": 10097,
  "local_host": "127.0.0.1",
  "local_port": 10097,
  "verify_ssl": false
}
```

## Windows microphone demo

`xiaoge_demo_mic_win` is a Windows-only realtime microphone demo. It captures
16 kHz mono int16 microphone frames, sends them to the Xiaoge session, prints
downlink JSON, and plays received PCM through the system speaker unless
playback is disabled.

Start the local proxy first:

```bash
python examples/local_proxy.py
```

Then run the microphone demo after building from the package root:

```bash
./build/xiaoge_demo_mic_win --seconds 20
```

Explicit form:

```bash
./build/xiaoge_demo_mic_win http://127.0.0.1:10097/create_session   robot-x3-001 '{"key_id":"dev","signature":"mock"}' --seconds 20
```

Options:

- `--seconds N`: run for N seconds; `0` means run until Ctrl-C.
- `--no-playback`: keep streaming microphone audio but skip speaker playback.
- `--ca-cert path`, `--insecure`, `--api-key key`: same meaning as the file demo.

The demo uses Windows `waveIn`/`waveOut`, so Windows microphone permission and a
working default input device are required. If the executable is built with a
dynamic MinGW runtime, make sure the required runtime DLLs are available on
`PATH`.
