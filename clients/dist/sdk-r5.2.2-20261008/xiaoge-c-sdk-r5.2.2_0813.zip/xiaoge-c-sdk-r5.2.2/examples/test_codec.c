#include "xiaoge_client.h"

#include <stdio.h>
#include <string.h>

int xiaoge_test_json_cloud_cmd_compatible(const char *cmd_json);
int xiaoge_test_build_cmd_ack_json(const char *cmd_json, const char *status, const char *code,
                                   const char *message, char *out, size_t out_len);
int xiaoge_test_build_cmd_result_json(const char *cmd_json, const char *status, const char *code,
                                      const char *message, int retryable, long long started_at_ms,
                                      long long finished_at_ms, long long duration_ms, char *out,
                                      size_t out_len);
int xiaoge_test_auto_fake_cmd_enabled(int value);

static int must(int ok, const char *message) {
    if (!ok) {
        fprintf(stderr, "FAIL %s\n", message);
        return 1;
    }
    return 0;
}

int main(void) {
    char body[2048];
    xiaoge_config cfg = {
        "robot-test",
        "{\"type\":\"mock\",\"value\":\"credential\"}",
        "audio,text,cmd,state",
        "xiaoge-c-test-r5.2.2",
        "{}",
    };

    int n = xiaoge_build_create_session_request(&cfg, body, sizeof(body));
    if (must(n > 0, "create_session request builds")) return 1;
    if (must(strstr(body, "\"caps\":[\"audio\",\"text\",\"cmd\",\"state\"]") != NULL, "caps serialized")) return 1;
    if (must(strstr(body, "\"sample_rate\":16000") != NULL, "sample rate serialized")) return 1;

    xiaoge_config dup_caps = cfg;
    dup_caps.caps_csv = "audio,audio";
    if (must(xiaoge_build_create_session_request(&dup_caps, body, sizeof(body)) == -1, "duplicate caps rejected")) {
        return 1;
    }

    xiaoge_config bad_caps = cfg;
    bad_caps.caps_csv = "audio,legacy";
    if (must(xiaoge_build_create_session_request(&bad_caps, body, sizeof(body)) == -1, "unknown caps rejected")) {
        return 1;
    }

    xiaoge_session bad_path = {
        "trace",
        "sess",
        "token",
        "ws://127.0.0.1/ws/audio",
        "audio,text",
        "cfg",
    };
    if (must(xiaoge_create_from_session(&cfg, &bad_path, 0, NULL) == NULL, "legacy ws path rejected")) return 1;

    if (must(xiaoge_send_pcm(NULL, "x", 1) == -1, "null pcm client rejected")) return 1;
    if (must(xiaoge_send_frontend_state(NULL, "bad", "awake", "speech", 1000) == -1,
             "null frontend_state client rejected")) {
        return 1;
    }

    const char *cloud_json =
        "{"
        "\"type\": \"data.cmd\", "
        "\"trace_id\": \"trace\", "
        "\"session_id\": \"sess\", "
        "\"utterance_id\": \"utt-cloud-json\", "
        "\"cmd_id\": \"cmd-cloud-json\", "
        "\"capability_id\": \"motion.move\", "
        "\"action\": \"navigation.move\", "
        "\"params\": {\"direction\": \"forward\", \"distance_cm\": 100}, "
        "\"risk_level\": \"medium\", "
        "\"ack_timeout_ms\": 800, "
        "\"result_timeout_ms\": 5000, "
        "\"issued_at_ms\": 1789000001000"
        "}";
    if (must(xiaoge_test_json_cloud_cmd_compatible(cloud_json) == 1,
             "cloud default JSON spacing accepted")) {
        return 1;
    }

    char frame[1024];
    if (must(xiaoge_test_build_cmd_ack_json(cloud_json, "accepted", "ok", "accepted", frame,
                                            sizeof(frame)) == 0,
             "cmd_ack builds")) {
        return 1;
    }
    if (must(strstr(frame, "\"type\":\"data.cmd_ack\"") != NULL, "cmd_ack type serialized")) return 1;
    if (must(strstr(frame, "\"status\":\"accepted\"") != NULL, "cmd_ack status serialized")) return 1;
    if (must(strstr(frame, "\"received_at_ms\":") != NULL, "cmd_ack timestamp serialized")) return 1;
    if (must(xiaoge_test_build_cmd_ack_json(cloud_json, "unknown", "bad", "bad", frame,
                                            sizeof(frame)) == -1,
             "invalid cmd_ack status rejected")) {
        return 1;
    }

    if (must(xiaoge_test_build_cmd_result_json(cloud_json, "succeeded", "ok", "done", 0, 11, 12,
                                               1, frame, sizeof(frame)) == 0,
             "cmd_result builds")) {
        return 1;
    }
    if (must(strstr(frame, "\"type\":\"data.cmd_result\"") != NULL, "cmd_result type serialized")) return 1;
    if (must(strstr(frame, "\"retryable\":false") != NULL, "cmd_result retryable serialized")) return 1;
    if (must(strstr(frame, "\"started_at_ms\":11") != NULL, "cmd_result start serialized")) return 1;
    if (must(strstr(frame, "\"finished_at_ms\":12") != NULL, "cmd_result finish serialized")) return 1;
    if (must(strstr(frame, "\"duration_ms\":1") != NULL, "cmd_result duration serialized")) return 1;
    if (must(xiaoge_test_build_cmd_result_json(cloud_json, "accepted", "bad", "bad", 0, -1,
                                               -1, -1, frame, sizeof(frame)) == -1,
             "invalid cmd_result status rejected")) {
        return 1;
    }

    const char *missing_cmd_id =
        "{\"type\":\"data.cmd\",\"trace_id\":\"trace\",\"session_id\":\"sess\","
        "\"utterance_id\":\"utt\"}";
    if (must(xiaoge_test_build_cmd_ack_json(missing_cmd_id, "accepted", "ok", "", frame,
                                            sizeof(frame)) == -1,
             "cmd_ack missing cmd_id rejected")) {
        return 1;
    }
    if (must(xiaoge_test_build_cmd_result_json(missing_cmd_id, "running", "ok", "", 0, -1,
                                               -1, -1, frame, sizeof(frame)) == -1,
             "cmd_result missing cmd_id rejected")) {
        return 1;
    }

    if (must(xiaoge_test_auto_fake_cmd_enabled(XIAOGE_AUTO_FAKE_CMD_DEFAULT) == 1,
             "default fake executor enabled")) {
        return 1;
    }
    if (must(xiaoge_test_auto_fake_cmd_enabled(XIAOGE_AUTO_FAKE_CMD_ENABLED) == 1,
             "explicit fake executor enabled")) {
        return 1;
    }
    if (must(xiaoge_test_auto_fake_cmd_enabled(XIAOGE_AUTO_FAKE_CMD_DISABLED) == 0,
             "fake executor disabled")) {
        return 1;
    }

    printf("records=c-codec-smoke failures=0\n");
    return 0;
}
